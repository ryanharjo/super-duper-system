﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variables_Harjo_Ryan
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declare an integer named "favoriteNumber"
            int favoriteNumber;
            // Initialize booleans "isJumping" and "isRunning" to false, on the same line
            bool isJumping = false, isRunning = false;

            // Declare a floating point variable (float)
            float myFloat;
            // Assign "favoriteNumber" to your favorite number
            favoriteNumber = 10;
            // Assign the floating point variable a floating point number
            myFloat = 40.4f;
            // Initialize a double that you do not want to change and name it "finalGrade"
            const double finalGrade = 89.0;

            // Print out all variables on their own line
            Console.WriteLine("Favorite #: " + favoriteNumber);
            Console.WriteLine("Jumping: " + isJumping);
            Console.WriteLine("Running: " + isRunning);
            Console.WriteLine("Random Floating #: " + myFloat);
            Console.WriteLine("Final Grade: " + finalGrade);
        }
    }
}
